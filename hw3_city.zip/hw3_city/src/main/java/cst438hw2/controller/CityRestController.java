package cst438hw2.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import cst438hw2.domain.*;
import cst438hw2.service.CityService;
/*
 * Rest controller to return cityInfo object in form of json if found or
 * throws exception if not found
 */
@RestController
public class CityRestController {

   @Autowired
   private CityService cityService;

   @GetMapping("/api/cities/{city}")
   public CityInfo getWeather(@PathVariable("city") String cityName) {
      
      Optional<CityInfo> cityInfo = cityService.getCityInfo(cityName);
      //return cityInfo object in form of json if object present
      if (cityInfo.isPresent()) {
         return cityInfo.get();
      }
      throw new ResponseStatusException(HttpStatus.NOT_FOUND);
   }
}
