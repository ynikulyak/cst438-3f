package cst438hw2.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cst438hw2.domain.*;

@Service
public class CityService {
   
   private static final Logger log = LoggerFactory.getLogger(CityService.class);

   @Autowired
   private CityRepository cityRepository;

   @Autowired
   private CountryRepository countryRepository;

   @Autowired
   private WeatherService weatherService;
   
   @Autowired
   private RabbitTemplate rabbitTemplate;
  
   @Autowired
   private FanoutExchange fanout;

   public Optional<CityInfo> getCityInfo(String cityName) {
      //return list of cities from db from table city
      List<City> cities = cityRepository.findByName(cityName);
      //take first city from the list
      Optional<City> cityOptional = cities.stream().findFirst();
      //if list is empty
      if (!cityOptional.isPresent()) {
         return Optional.empty();
      }
      
      //take city object from Optional
      City c = cityOptional.get();
      
      //find country by code from db from table country
      Optional<Country> countryOptional = countryRepository.findByCode((c.getCountryCode()));
      //if no country was found
      if(!countryOptional.isPresent()) {
         log.warn("Country for {} city was not found", cityName);
         return Optional.empty();
      }
      
      //take country object
      Country country = countryOptional.get();
      
      String countryName = country.getName();
      //return time and temp from external api using weather service
      Optional<TempAndTime> tempAndTimeOptional = weatherService.getTempAndTime(cityName);
      //check if exists
      if(!tempAndTimeOptional.isPresent()) {
         log.warn("Weather for {} city was not found", cityName);
         return Optional.empty();
      }
      
      //take object
      TempAndTime tempAndTime = tempAndTimeOptional.get();
      
      //take temp fiel of object
      double temperature = tempAndTime.temp;
      //convert to F
      temperature = Math.round((temperature - 273.15) * 9.0/5.0 + 32.0);
      
      int timezone = tempAndTime.timezone;
      timezone = timezone/ 3600;
      
      long t = tempAndTime.time;
      
      LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(t, 0, ZoneOffset.ofHours(timezone));
      String time = localDateTime.format(DateTimeFormatter.ofPattern("h:mm a"));
      
      return Optional.of(new CityInfo(c.getId(), c.getName(), c.getCountryCode(), countryName, 
            c.getDistrict(), c.getPopulation(), temperature, time));  
   }

   //methods that will write a message to an exchange using the RabbitTemplate class provided by Spring
   public void requestReservation(String cityName, String level, String email) {
     String msg  = "{\"cityName\": \""+ cityName + "\" \"level\": \""+level+
              "\" \"email\": \""+email+"\"}" ;
     System.out.println("Sending message:"+msg);
     rabbitTemplate.convertSendAndReceive(fanout.getName(), "",   // routing key none.
               msg);
  }
}
