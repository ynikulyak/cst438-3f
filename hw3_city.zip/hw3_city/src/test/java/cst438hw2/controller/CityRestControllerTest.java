package cst438hw2.controller;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.Optional;

import cst438hw2.domain.*;
import cst438hw2.service.CityService;


@WebMvcTest(CityRestControllerTest.class)
public class CityRestControllerTest {

   @MockBean
   private CityService cityService;

   @Autowired
   private MockMvc mvc;

   // This object will be magically initialized by the initFields method below.
   private JacksonTester<CityInfo> json;

   @Before
   public void setup() {
      JacksonTester.initFields(this, new ObjectMapper());
   }

   @Test
   public void getCityInfo() throws Exception {

      // expected cityInfo object
      CityInfo city = new CityInfo(3794, "Los Angeles", "USA", "United States", 
            "California", 3694820, 73.0, "test time");

      // stub out the City Service class
      given(cityService.getCityInfo("Los Angeles")).willReturn(Optional.of(city));

      // when
      MockHttpServletResponse response = mvc.perform(get("/api/cities/Los%20Angeles")
            .contentType(MediaType.APPLICATION_JSON).content(json.write(city).
                  getJson())).andReturn().getResponse();

      // then
      assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
      assertThat(response.getContentAsString()).isEqualTo(json.write(city).getJson());
   }

   @Test
   public void getCityInfoNotFound() throws Exception {

      // stub out the City Service class
      given(cityService.getCityInfo("AAAA")).willReturn(Optional.empty());

      // when
      MockHttpServletResponse response = (MockHttpServletResponse) mvc.perform(get("/api/cities/AAAA"));

      // then
      assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
   }

}
