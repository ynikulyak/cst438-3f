package cst438hw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cst438hw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
