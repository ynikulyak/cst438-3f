package cst438hw2.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.BDDMockito.given;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.mockito.ArgumentMatchers.anyString;

import cst438hw2.domain.*;

@SpringBootTest
public class CityServiceTest {

   @MockBean
   private WeatherService weatherService;

   @MockBean
   private CityRepository cityRepository;

   @MockBean
   private CountryRepository countryRepository;

   @Autowired
   private CityService cityService;

   @Test
   public void testCityFound() throws Exception {
      //create all necessary mocks
      List<City> cities = Arrays.asList(new City(3793L, "New York", "USA", "New York", 8008278));
      given(cityRepository.findByName("New York")).willReturn(cities);

      Optional<Country> country = Optional.of(new Country("USA", "United States"));
      given(countryRepository.findByCode("USA")).willReturn(country);

      Optional<TempAndTime> tempAndTime = Optional.of(new TempAndTime(340.0, 1580502359, -18000));
      given(weatherService.getTempAndTime("New York")).willReturn(tempAndTime);

      //call real service
      Optional<CityInfo> cityInfoOptional = cityService.getCityInfo("New York");
      
      // Test results.
      //check if object found
      assertThat(cityInfoOptional).isPresent();
      
      //verify that actual cityInfo object is correct
      CityInfo cityInfo =  cityInfoOptional.get();
      assertThat(cityInfo.getId()).isEqualTo(3793);
      assertThat(cityInfo.getName()).isEqualTo("New York");
      assertThat(cityInfo.getCountryCode()).isEqualTo("USA");
      assertThat(cityInfo.getCountryName()).isEqualTo("United States");
      assertThat(cityInfo.getDistrict()).isEqualTo("New York");
      assertThat(cityInfo.getPopulation()).isEqualTo(8008278);
      assertThat(cityInfo.getTemp()).isEqualTo(152.0);
      assertThat(cityInfo.getTime()).isEqualTo("3:25 PM");
   }

   @Test
   public void testCityNotFound() {
      List<City> cities = Collections.EMPTY_LIST;
      given(cityRepository.findByName("AAAA")).willReturn(cities);
      
      Optional<CityInfo> cityInfoOptional = cityService.getCityInfo("AAAA");
      
      assertThat(cityInfoOptional).isNotPresent(); 
   }

   @Test
   public void testCityMultiple() {
      
      List<City> cities = Arrays.asList(new City(3794,"Los Angeles","USA","California",3694820),
            new City(568,"Los Angeles","CHL","B�ob�o",158215));
      given(cityRepository.findByName("Los Angeles")).willReturn(cities);

      Optional<Country> country = Optional.of(new Country("USA", "United States"));
      given(countryRepository.findByCode("USA")).willReturn(country);

      Optional<TempAndTime> tempAndTime = Optional.of(new TempAndTime(340.0, 1580502359, -18000));
      given(weatherService.getTempAndTime("Los Angeles")).willReturn(tempAndTime);

      // All mocks are ready, now call the service itself to test it.
      Optional<CityInfo> cityInfoOptional = cityService.getCityInfo("Los Angeles");
      
      // Test results.
      assertThat(cityInfoOptional).isPresent();
      
      CityInfo cityInfo =  cityInfoOptional.get();
      assertThat(cityInfo.getId()).isEqualTo(3794);
      assertThat(cityInfo.getName()).isEqualTo("Los Angeles");
      assertThat(cityInfo.getCountryCode()).isEqualTo("USA");
      assertThat(cityInfo.getCountryName()).isEqualTo("United States");
      assertThat(cityInfo.getDistrict()).isEqualTo("California");
      assertThat(cityInfo.getPopulation()).isEqualTo(3694820);
      assertThat(cityInfo.getTemp()).isEqualTo(152.0);
      assertThat(cityInfo.getTime()).isEqualTo("3:25 PM");
   }
}
